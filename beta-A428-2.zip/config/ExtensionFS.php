<?php

return [
  'disks' => [
    /* blueprint/disks */
  ],
];